/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	 
config.toolbarGroups = [
     
      { name: 'basicstyles', groups: ['basicstyles', 'cleanup'] },
       { name: 'colors' },
      '/',
      { name: 'styles' },
{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
		{ name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align' ] }
      
    ];
config.height = 200;
config.width = 690;
    // ȡ������ק�Ըı�ߴ硱���� plugins / resize / plugin.js
    // config.resize_enabled = false;
config.entities_greek = true; // �Ƿ�ת��һЩ������ʾ���ַ�Ϊ��Ӧ�� HTML�ַ� 
//config.fontSize_defaultLabel = '12px';
config.language = 'zh-cn';
    //������Ĭ���Ƿ�չ��
config.toolbarStartupExpanded = true;
    // config.toolbarCanCollapse = true;
    // Remove some buttons, provided by the standard plugins, which we don't
    // need to have in the Standard(s) toolbar.
config.removeButtons = 'Underline,Subscript,Superscript';
config.enterMode = CKEDITOR.ENTER_BR;
config.shiftEnterMode = CKEDITOR.ENTER_P;
	
};
